//
//  Tips04App.swift
//  Tips04
//
//  Created by hondasan on 2022/4/29.
//

import SwiftUI

@main
struct Tips04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
