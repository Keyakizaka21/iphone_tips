//
//  TipsModel.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import Foundation
import Combine

final class TipsModel: ObservableObject{
    
    @Published var tips: [Tip] = JSONParser()
    
}

func JSONParser <T: Decodable> () -> T {
    
    guard let fileURL = Bundle.main.url(forResource: "TipsData.json", withExtension: nil),
          let data = try? Data.init(contentsOf: fileURL) else{
              fatalError("JSON File Fetch Failed")
          }
    
    do{
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    }catch{
        fatalError("JSON Decode Failed")
    }
            
}
