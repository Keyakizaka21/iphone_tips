//
//  RowData.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import Foundation

struct RowData: Hashable, Identifiable{
    
    var id = UUID()
    var imageString: String
    var titleString: String
    var subTitleString: String
    var tipCount: Int
    
}

let rowData: [RowData] = [
    RowData(imageString: "NULL", titleString: "新功能", subTitleString: "NULL", tipCount: 7),
    RowData(imageString: "iphone", titleString: "欢迎使用iPhone", subTitleString: "了解你的iPhone", tipCount: 8),
    RowData(imageString: "star", titleString: "基本功能", subTitleString: "不可不知的使用功能", tipCount: 9),
    RowData(imageString: "gyroscope", titleString: "Genius精选", subTitleString: "专家精挑细选的提示", tipCount: 16),
    RowData(imageString: "person.2.circle", titleString: "辅助功能", subTitleString: "让iPhone操纵自如", tipCount: 9),
    RowData(imageString: "camera.aperture", titleString: "摄影", subTitleString: "拍摄最佳照片", tipCount: 11),
    RowData(imageString: "heart", titleString: "健康", subTitleString: "查看您的数据，掌握最新情况", tipCount: 6),
    RowData(imageString: "play", titleString: "Siri", subTitleString: "使用Siri实现更多操作", tipCount: 2)

]
