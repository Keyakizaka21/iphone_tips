//
//  TipsStruct.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import Foundation

struct Tip : Hashable, Decodable, Identifiable{
    
    var id : Int
    var pageId: Int
    
    var belongRow: String
    var tipTitle: String
    var tipDetails: String
    
    var isButton: Bool
    var url: String
    
    var isSFsymbol: Bool
    var textNum: Int
    
    var showmode: modes
    enum modes: String, CaseIterable, Codable{
        case image
        case video
    }
    
}
