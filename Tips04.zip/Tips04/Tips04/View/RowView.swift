//
//  RowView.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import SwiftUI

struct RowView: View {
    
    var imageString: String
    var titleString: String
    var subTitleString: String
    var tipCount: Int
    
    var body: some View {
        HStack{
            Image(systemName: imageString)
                .font(.system(size: 50))
                .scaledToFit()
                .frame(width: 100, height: 100)
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                
            
            VStack(alignment: .leading){
                Text(titleString)
                    .font(.system(size: 20))
                    .fontWeight(.bold)
                Text(subTitleString)
                    .font(.callout)
                    .foregroundColor(.primary)
                Text("\(tipCount)条提示")
                    .font(.callout)
                    .foregroundColor(.secondary)
            }
        }
    }
}

struct RowView_Previews: PreviewProvider {
    static var previews: some View {
        RowView(imageString: "star", titleString: "基本功能", subTitleString: "不可不知的使用功能", tipCount: 9)
    }
}
