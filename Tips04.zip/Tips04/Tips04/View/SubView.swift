//
//  SubView.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import SwiftUI
import Pages

struct SubView: View {
    
    @ObservedObject var tipsModel: TipsModel
    @State var index: Int = 0
    
    var BelongRow: String
    var pagetips: [Tip] {
        tipsModel.tips.filter{
            Tip in
            (Tip.belongRow == BelongRow)
        }
    }
    
    let ImageWidth = UIScreen.main.bounds.width
    
    var body: some View {
        
        ZStack{
            
            ModelPages(pagetips, currentPage: $index, hasControl: false){ pageIndex, tip in
                
                VStack(alignment: .leading){
                    
                    Image("\(tip.belongRow)\(tip.pageId)")
                        .resizable()
                        .scaledToFit()
                        .frame(width: ImageWidth, height: ImageWidth)
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text(tip.tipTitle)
                            .font(.title3)
                            .fontWeight(.bold)
                        
                        if tip.tipDetails == "Additional Processing"{
                            getSFsymbolText(TextIndex: tip.textNum)
                                .font(.callout)
                        }else{
                            Text(tip.tipDetails)
                                .font(.callout)
                        }
                        
                        
                    }
                    .padding(.horizontal, 25)
                    .padding(.vertical)
                    
                    if tip.isButton{
                        
                        HStack{
                            
                            Spacer()

                            Button(action: gotoSetting){
                                
                                if tip.tipTitle == "监控步行稳定性" {
                                    Text("查看核对清单")
                                        .foregroundColor(Color(.label))
                                }else{
                                    Text("前往“设置”")
                                        .foregroundColor(Color(.label))
                                }
                                
                            }
                            .frame(width: 120, height: 50, alignment: .center)
                            .background(Color(.systemGray5))
                            .cornerRadius(5)
                            .padding(.horizontal)
                            Spacer()
                            
                        }
                        
                    }
                    
                    
                    Spacer()
                    
                    
                    
                    
                }
                
            }//ModelPages
            VStack{
                Spacer()
                PageControl(numberOfPages: pagetips.count, currentPage: $index)
                    .frame(width: CGFloat(pagetips.count * 18))
                    .padding()
                
            }
           
            
        }//ZStack
        .navigationBarTitle(Text(BelongRow), displayMode: .inline)
        

    }

}

struct SubView_Previews: PreviewProvider {
    static var previews: some View {
        SubView(tipsModel: TipsModel(), BelongRow: "基本功能")
    }
}
