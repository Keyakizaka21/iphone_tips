//
//  ContainerView.swift
//  Tips
//
//  Created by hondasan on 2022/4/27.
//

import SwiftUI
import AVKit
import AVFoundation

struct ContainerView: View {
    
    @State var isdelay: Bool = true
    
    var urlString: String
    
    let ImageWidth = UIScreen.main.bounds.width
    let PlayerWidth = UIScreen.main.bounds.width
    
    var body: some View {
        
        let Myurl = Bundle.main.url(forResource: urlString, withExtension: "mov")!
        let Myplayer = AVPlayer(url: Bundle.main.url(forResource: urlString, withExtension: "mov")!)
        
        ZStack{
            
            Image(uiImage: getFirstFrame(url: Myurl, at: 0)!)
                .resizable()
                .frame(width: ImageWidth, height: ImageWidth)
                .opacity(isdelay ? 1 : 0)
                .onAppear(perform: {
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                        self.isdelay = false
                    }
                    
                })
            
            
            AVPlayerControllerRepresented(player: Myplayer)
                .frame(width: PlayerWidth, height: PlayerWidth)
                .opacity(isdelay ? 0 : 1)
                .onAppear{
                    
                    Myplayer.play()
                    
                }
                
            
            
        }
        
        
    }
}

struct ContainerView_Previews: PreviewProvider {
    static var previews: some View {
        ContainerView(urlString: "New1")
    }
}
