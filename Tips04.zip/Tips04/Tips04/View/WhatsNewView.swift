//
//  WhatsNewView.swift
//  Tips
//
//  Created by hondasan on 2022/4/26.
//

import SwiftUI
import Pages
import AVKit
import AVFoundation

struct WhatsNewView: View {
    
    @ObservedObject var tipsModel: TipsModel
    @State var index: Int = 0
    
    var pagetips: [Tip] {
        tipsModel.tips.filter{
            Tip in
            (Tip.belongRow == "新功能")
        }
    }
    let ImageWidth = UIScreen.main.bounds.width
    let PlayerWidth = UIScreen.main.bounds.width
    
    var body: some View {
        
        ZStack{
            
            ModelPages(pagetips, currentPage: $index, hasControl: false){ pageIndex, tip in
                
                VStack(alignment: .leading){
                    
                    if tip.showmode.rawValue == "video"{
                        
                        ContainerView(urlString: "New\(tip.pageId)")
                        
                    }else{
                        Image("\(tip.belongRow)\(tip.pageId)")
                            .resizable()
                            .scaledToFit()
                            .frame(width: ImageWidth, height: ImageWidth)
                    }

                    
                    VStack(alignment: .leading, spacing: 10){
                        Text(tip.tipTitle)
                            .font(.title3)
                            .fontWeight(.bold)
                        
                        if tip.tipDetails == "Additional Processing"{
                            getSFsymbolText(TextIndex: tip.textNum)
                                .font(.callout)
                        }else{
                            Text(tip.tipDetails)
                                .font(.callout)
                        }
                        
                        
                    }
                    .padding(.horizontal, 25)
                    .padding(.vertical)
                    
                    if tip.isButton{
                        
                        if tip.tipTitle == "进一步了解"{
                            HStack{
                                Button(action: gotoWeb){
                                    Text("前往apple.com")
                                        .font(.callout)
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding(.horizontal, 25)
                        }else{
                            HStack{
                                
                                Spacer()
                                Button(action: gotoSetting){
                                    Text("前往“设置”")
                                        .foregroundColor(Color(.label))
                                }
                                .frame(width: 120, height: 50, alignment: .center)
                                .background(Color(.systemGray5))
                                .cornerRadius(5)
                                .padding(.horizontal)
                                Spacer()
                                
                            }
                        }
                        
                        
                        
                    }
                    Spacer()
                    
                }
                
            }//ModelPages
            VStack{
                Spacer()
                PageControl(numberOfPages: pagetips.count, currentPage: $index)
                    .frame(width: CGFloat(pagetips.count * 18))
                    .padding()
                
            }
           
            
        }//ZStack
        .navigationBarTitle(Text("新功能"), displayMode: .inline)
    }
}

struct WhatsNewView_Previews: PreviewProvider {
    static var previews: some View {
        WhatsNewView(tipsModel: TipsModel())
    }
}
