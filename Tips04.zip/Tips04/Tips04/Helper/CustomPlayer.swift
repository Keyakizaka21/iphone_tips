//
//  CustomPlayer.swift
//  Tips
//
//  Created by hondasan on 2022/4/27.
//

import SwiftUI
import AVKit
import AVFoundation

struct AVPlayerControllerRepresented: UIViewControllerRepresentable {
    
    var player: AVPlayer
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        
    }
}
