//
//  functions.swift
//  Tips
//
//  Created by hondasan on 2022/4/27.
//

import Foundation
import SwiftUI
import AVKit
import AVFoundation

func getSFsymbolText(TextIndex: Int) -> some View{
    
    switch TextIndex {
        
        //can find sf symbol for case 2, case 10, case14
    case 1: return
        Text("将打开的Safari浏览器标签页存储为“标签页组”，便于您仅查看想要的网页。轻点\(Image(systemName: "square.on.square"))，轻点“标签页”，然后轻点“新建标签页组”。")
        
    case 2: return Text("结账时查找这些标志：\(Image(systemName: "sun.min"))或\(Image(systemName: "sun.min"))。若要支付，请将手指放在主屏幕按钮上以通过触控ID进行认证，然后将iPhone靠近读卡器。")
        
    case 3: return Text("轻点两下信息，然后选取一个点回，如\(Image(systemName: "heart.fill"))或\(Image(systemName: "hand.thumbsup.fill"))。")
        
    case 4: return Text("您可以与附近的人共享照片、网站、联系人等等。轻点\(Image(systemName: "square.and.arrow.up"))，然后轻点“隔空投送”。")
        
    case 5: return Text("在Pages文稿中，切换到专为移动编辑而优化的布局。在文字处理文稿中，轻点\(Image(systemName: "ellipsis.circle"))，然后打开“屏幕视图”。您可以再将它关闭来查看完整布局。")
        
        
    case 6: return Text("在“天气”App中，轻点\(Image(systemName: "map"))以查看该地区的气温、降水和空气质量。轻点\(Image(systemName: "square.stack.3d.up"))切换地图。")
        
    case 7: return Text("您可以在信息、电子邮件、备忘录等任何使用键盘的地方听写文本。轻点\(Image(systemName: "mic.fill"))，然后开始说话。完成后，轻点\(Image(systemName: "keyboard"))。")
        
    case 8: return Text("给自己预留时间进入镜头。轻点\(Image(systemName: "timer"))，然后轻点时间。将iPhone放稳，然后轻点\(Image(systemName: "circle.inset.filled")) 以开始倒计时。")
        
    case 9: return Text("轻点屏幕以更改照片的对焦点。若要调整亮度，请轻点屏幕，然后拖移\(Image(systemName: "sun.min")) 。")
        
    case 10: return Text("不在摄影室中也可创建摄影室品质的灯光效果。在“相机”中，选取“人像”模式，然后拖移\(Image(systemName: "sun.min")) 来更改效果。")
        
    case 11: return Text("在“图库”标签页中，轻点“选择”，然后在相簿中轻扫想要的照片。轻点\(Image(systemName: "square.and.arrow.up"))，轻点“添加到相簿”，然后轻点“新建相簿”。")
        
    case 12: return Text("直接从主屏幕回顾特别时刻。按住主屏幕，轻点\(Image(systemName: "plus"))，然后轻点“照片”。")
        
    case 13: return Text("编辑实况照片以捕捉精彩瞬间。轻点“编辑”，轻点\(Image(systemName: "livephoto"))，拖移帧，然后轻点“设为封面照片”。")
        
    case 14: return Text("在“为您推荐”标签页中，轻点回忆以进行播放。轻点屏幕，轻点\(Image(systemName: "sun.min"))，然后轻扫以查看搭配精选歌曲和风格的不同回忆混剪。轻点屏幕以应用更改。")
        
    case 15: return Text("控制哪些人会出现在精选照片和“回忆”中。轻点\(Image(systemName: "info.circle"))，轻点人物的缩略图，轻点“减少出现”，然后选取以减少出现此人或永不出现此人。")
    
    default: return Text("Empty")
    }
}

func getMyPlayer(id: Int) -> AVPlayer{
    let Myplayer = AVPlayer(url: Bundle.main.url(forResource: "New\(id)", withExtension: "mov")!)
    return Myplayer
}

func getFirstFrame(url: URL, at time: TimeInterval) -> UIImage? {
    
    let asset = AVURLAsset(url: url)
    let assetIG = AVAssetImageGenerator(asset: asset)
    assetIG.appliesPreferredTrackTransform = true
    assetIG.apertureMode = AVAssetImageGenerator.ApertureMode.encodedPixels
    
    let cmTime = CMTime(seconds: time, preferredTimescale: 60)
    let cutImage: CGImage
    do{
        
        cutImage = try assetIG.copyCGImage(at: cmTime, actualTime: nil)
    
    }catch let error {
        
        print("Error: \(error)")
        return nil
        
    }
    
    return UIImage(cgImage: cutImage)
    
}

func gotoSetting(){
    
    guard let url = URL(string: UIApplication.openSettingsURLString)else{
        return
    }
    
    if #available(iOS 10, *){
        UIApplication.shared.open(url, options: [ : ], completionHandler: nil)
        
    }else{
        UIApplication.shared.openURL(url)
    }
    
}

func gotoWeb(){
    
    let urlString = "https://www.apple.com/"
    if let url = URL(string: urlString){
        
        if #available(iOS 10, *){
            UIApplication.shared.open(url, options: [ : ], completionHandler: {(success) in })
            
        }else{
            UIApplication.shared.openURL(url)
        }
        
    }
    
    
}
