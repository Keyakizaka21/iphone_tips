//
//  ContentView.swift
//  Tips04
//
//  Created by hondasan on 2022/4/29.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var tipsModel = TipsModel()
    let ImageWidth = UIScreen.main.bounds.width - 40
    
    init(){
        UITableView.appearance().showsVerticalScrollIndicator = false
    }
    
    var body: some View {
        NavigationView{
            List{
                ForEach(rowData, id: \.self){item in
                    
                    if item.titleString == "新功能"{
                        ZStack{
                            Image("Home")
                                .resizable()
                                .scaledToFit()
                                .frame(width: ImageWidth, height: ImageWidth * (2/3))
                                .cornerRadius(10)
                            NavigationLink(destination: WhatsNewView(tipsModel: tipsModel), label: {})
                                .opacity(0)
                        }
                       
                    }else if item.titleString == "欢迎使用iPhone"{
                        NavigationLink{
                            WelcomeView(tipsModel: tipsModel)
                        } label: {
                            RowView(imageString: item.imageString, titleString: item.titleString, subTitleString: item.subTitleString, tipCount: item.tipCount)
                        }
                    }else{
                        NavigationLink{
                            SubView(tipsModel: tipsModel, BelongRow: item.titleString)
                        } label: {
                            RowView(imageString: item.imageString, titleString: item.titleString, subTitleString: item.subTitleString, tipCount: item.tipCount)
                        }
                    }
                    
                    
                    
                    
                    
                }
                
                
                
                
            }
            .listStyle(.inset)
            .navigationTitle("精选")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(TipsModel())
    }
}
